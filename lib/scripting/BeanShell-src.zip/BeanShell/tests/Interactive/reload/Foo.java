
public class Foo {
	public void run() {
		System.out.println("Foo v3");
		new Bar().run();
	}
}
