
public class Bar {
	public void run() {
		System.out.println("Bar v2");
	}
}
