
public class Animal {
	public void run() {
		System.out.println("animal v2");
	}
}
