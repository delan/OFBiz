
public class Cat extends Animal {
	public void run() {
		System.out.println("cat v2");
		super.run();
	}
}
