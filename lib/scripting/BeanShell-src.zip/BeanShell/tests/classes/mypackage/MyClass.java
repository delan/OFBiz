package mypackage;

public class MyClass {
	public MyClass() {
		System.out.println("MyClass constructor: bar");
	}
}

