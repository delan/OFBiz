export CVS_RSH=/pkg/ssh-1.2.31/bin/ssh1
export CVSROOT=patn@cvs.beanshell.sourceforge.net:/cvsroot/beanshell

