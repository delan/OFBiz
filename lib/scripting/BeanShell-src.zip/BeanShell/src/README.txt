
-- This is BeanShell --

For update and documentation see 

	http://www.beanshell.org/

-- JDK Versions and Building the Source --

BeanShell is designed to work with versions of Java 1.1 and greater but 
some features will not be available with versions prior to 1.3.

For exaple, the file XThis.java is a module loaded only when bsh is run under 
JDK1.3 or greater.  It makes use of certain features of the reflection API 
that will not compile with JDK1.2 or lower.

--

