package generic;

import javax.swing.text.*;
import pattern.*;
import javax.swing.*;

public interface ICheckBoxModel extends ButtonModel, IGuiModel{
}
