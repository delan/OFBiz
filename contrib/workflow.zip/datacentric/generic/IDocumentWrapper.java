package generic;

import pattern.*;

public interface IDocumentWrapper extends IModelProxySupportClass, IDocument{
}
