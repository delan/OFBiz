package generic;

import pattern.*;

public interface IListWrapper extends IModelProxySupportClass, IListModel{
}
