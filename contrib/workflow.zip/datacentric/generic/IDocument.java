package generic;

import javax.swing.text.*;
import pattern.*;

public interface IDocument extends Document, IGuiModel{
}
