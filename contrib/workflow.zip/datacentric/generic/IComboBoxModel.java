package generic;

import pattern.IGuiModel;
import javax.swing.*;

public interface IComboBoxModel extends MutableComboBoxModel, IGuiModel{
	public int getIndexOf(Object obj);
	public void removeAllElements();
}
