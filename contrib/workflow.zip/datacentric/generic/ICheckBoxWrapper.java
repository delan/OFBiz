package generic;

import pattern.*;

public interface ICheckBoxWrapper extends IModelProxySupportClass, ICheckBoxModel{
}
