package generic;

import pattern.*;

public interface IComboBoxWrapper extends IModelProxySupportClass, IComboBoxModel{
}
