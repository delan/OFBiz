package com.objectspace.xml;

import java.io.Serializable;

public interface IIDRefBinding extends Serializable { 
	public Object getIdRef( String id );    
	public void setIdRef( String id, Object object );
	public void removeIdRef( String id );
}
