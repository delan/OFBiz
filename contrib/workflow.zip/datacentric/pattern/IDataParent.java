package pattern;

public interface IDataParent {
	public void removeChildData(Object child);
}
