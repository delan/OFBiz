package com.objectspace.xml;

import java.util.Hashtable;

import java.io.Serializable;

/**
 *		This class is part of the dxml package.  However, we have added a method removeIdRef.
 * 
 */
public class IDRefBinding implements IIDRefBinding { 
	static final long serialVersionUID = 752406216412860853L;
	
	Hashtable binding = new Hashtable();

	public Object getIdRef( String id ) { 
		return binding.get( id );
	}
	
	public void setIdRef( String key, Object value ) { 
		binding.put( key, value );
	}
	
	public void removeIdRef(String key){
		binding.remove(key);
	}
}
