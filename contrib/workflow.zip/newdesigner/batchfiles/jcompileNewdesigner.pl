$srcroot = "c:/workflow/newdesigner";
$javacstr = "c:/java/jdk1.3/bin/javac";
$targetdir = "c:/workflow/classes";

$targetstr = "-d $targetdir";
$cpstr = "-classpath $targetdir;c:/workflow/lib/dxml.jar;c:/workflow/lib/xml4j.jar;c:/java/jdk1.3/jre/lib/rt.jar"; 

@startdir = ($srcroot);

use File::Find;
sub process_file {
	/.java$/ && ($dirhash{$File::Find::dir} = "nothing");
}

find(\&process_file, @startdir);

foreach(keys %dirhash) {
	$dirstr .= "$_/*.java ";
}

$execstr = "$javacstr $cpstr $targetstr $dirstr";
system("cls");
print("$execstr\n\n\n");
system($execstr);