$srcroot = "c:/workflow";
$javacstr = "c:/java/jdk1.3/bin/javac";
$targetdir = "c:/workflow/classes";

$targetstr = "-d $targetdir";
$cpstr = "-classpath $targetdir;c:/workflow/lib/dxml.jar;c:/workflow/lib/xml4j.jar;c:/java/jdk1.3/jre/lib/rt.jar;c:/workflow/lib/jsse.jar;c:/workflow/lib/jnet.jar;c:/workflow/lib/jcert.jar;c:/lib/gef.jar"; 

@startdir = ($srcroot);

use File::Find;
sub process_file {
	/.java$/ && ($dirhash{$File::Find::dir} = "nothing");
}

find(\&process_file, @startdir);

foreach(keys %dirhash) {
	$dirstr .= "$_/*.java ";
}

$execstr = "$javacstr $cpstr $targetstr $dirstr";
system("cls");
print("$execstr\n\n\n");
system($execstr);