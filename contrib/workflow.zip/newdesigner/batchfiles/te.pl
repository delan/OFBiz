

   $rootdir = "c:\\workflow\\newdesigner";
   $xmldir = "$rootdir\\xml";
   $dtddir = "$rootdir\\dtd";
   $taskxml = "$xmldir\\task\\DEMO2level.xml";
   $domainxml = "$xmldir\\domainenv\\DefaultDomain.xml";
   $gifdir = "$rootdir\\gif";
   $taskname = "DEMO2level";
   system("cls");
   system ("java -DGIFDIR=$gifdir -DWF_XMLDIR=$xmldir -DWF_DTDDIR=$dtddir  newdesigner.TaskEditor $taskxml $taskname $domainxml");

