$source = "c:\\workflow\\newdesigner\\operatoreditor\\InputOperatorEditorTranslator.java";
$destination = "c:\\workflow\\newdesigner\\operatoreditor\\OutputOperatorEditorTranslator.java";

open(SOURCE, "< $source")
    or die "Couldn't open $source for reading: $!\n";

chmod(0666, $destination);
open(DESTINATION, "> $destination")
    or die "Couldn't open $destination for writing: $!\n";


print DESTINATION "//WARNING !! DO NOT MODIFY THIS FILE\n";
print DESTINATION "//THIS FILE IS GENERATED VIA SCRIPT\n";
print DESTINATION "//MODIFY $source INSTEAD\n\n\n";

$v1 = "getAndOperatorOrOrInputOperator";
$v2 = "getAndOperatorOrOrOutputOperatorOrLoopOperator";
$skip = "false";
while (<SOURCE>) {
   if ( /PL_STARTSKIP/) {
         ($skip eq "true") and die "skip already started";
         $skip = "true";
         next;
  }
  if ( /PL_STOPSKIP/) {
        ($skip eq "false") and die "skip already stopped";
         $skip = "false";
         next;
  }
  ($skip eq "true") and next;
  
   s/\(\(IInArc\)elements.nextElement\(\)\).getLink\(\).getIdrefAttribute\(\)/\(\(ILink\)elements.nextElement\(\)\).getIdrefAttribute\(\)/g;
   s/(.*)\(dataObject =\(IRegistrar\)wrapper.$v1\(\).getOrInputOperator\(\)\) != null\)/\1\(dataObject =\(IRegistrar\)wrapper.$v2\(\).getOrOutputOperator\(\)\) != null ||\n\1\(dataObject =\(IRegistrar\)wrapper.$v2\(\).getLoopOperator\(\)\) != null\)/g;
   s/$v1/$v2/g;
   s/getInArcElements/getLinkElements/g;
   s/Input/Output/g;
   s/InArc/OutArc/g;
   print DESTINATION;
}

close DESTINATION;
chmod(0000, $destination);
