
   open (DESTINATION, "> c:\\workflow\\util\\bigfile.txt");
   &processDir ("c:\\workflow\\util", "util");
   &processDir ("c:\\workflow\\datacentric\\generic", "datacentric");
   &processDir ("c:\\workflow\\datacentric\\pattern", "datacentric");
   &processDir ("c:\\workflow\\datacentric", "datacentric");
   &processDir ("C:\\workflow\\newdesigner\\modified\\dataclass", "dataclass (modified)");
   &processDir ("C:\\workflow\\newdesigner\\modified\\domainenv", "domainenv (modified)");
   &processDir ("C:\\workflow\\newdesigner\\modified\\networkdesign", "networkdesign (modified)");
   &processDir ("C:\\workflow\\newdesigner\\modified\\roledomain", "roledomain (modified)");
   &processDir ("C:\\workflow\\newdesigner\\dxml\\dataclass", "dataclass (dxml generated)");
   &processDir ("C:\\workflow\\newdesigner\\dxml\\domainenv", "domainenv (dxml generated)");
   &processDir ("C:\\workflow\\newdesigner\\dxml\\networkdesign", "networkdesign (dxml generated)");
   &processDir ("C:\\workflow\\newdesigner\\dxml\\roledomain", "roledomain (dxml generated)");
   &processDir ("C:\\workflow\\newdesigner\\wrapper\\dataclass", "dataclass (datacentric wrapper for dxml generated class)");
   &processDir ("C:\\workflow\\newdesigner\\wrapper\\domainenv", "domainenv (datacentric wrapper for dxml generated class)");
   &processDir ("C:\\workflow\\newdesigner\\wrapper\\networkdesign", "networkdesign (datacentric wrapper for dxml generated class)");
   &processDir ("C:\\workflow\\newdesigner\\wrapper\\roledomain", "roledomain (datacentric wrapper for dxml generated class)");
   &processDir ("C:\\workflow\\newdesigner\\src", "newdesigner");
   &processDir ("C:\\workflow\\newdesigner\\src\\model", "newdesigner.model");
   &processDir ("C:\\workflow\\newdesigner\\src\\operatoreditor", "newdesigner.operatoreditor");
   &processDir ("C:\\workflow\\newdesigner\\src\\popup", "newdesigner.popup");
   &processDir ("C:\\workflow\\newdesigner\\src\\latticeeditor", "latticeeditor");
   &processDir ("C:\\workflow\\newdesigner\\src\\latticeeditor\\model", "latticeeditor.model");
   &processDir ("C:\\workflow\\newdesigner\\src\\dataeditor", "dataeditor");
   &processDir ("C:\\workflow\\newdesigner\\src\\dataeditor\\model", "dataeditor.model");
   


sub processDir {
   $dirname = $_[0];
   $packagename = $_[1];
   opendir(DIR, $dirname) or die "can't opendir $dirname: $!";
   while (defined($file = readdir(DIR))) {
       next unless ($file =~ /^.*\.java$/);
       open (SOURCE, "< $dirname\\$file") or die "could not open $file";
       print DESTINATION "//  ***************************************************\n";
       print DESTINATION "// package $packagename\n";
       print DESTINATION "// $file\n";
       print DESTINATION "//  ***************************************************\n";
       print DESTINATION while (<SOURCE>) ;
       print DESTINATION "\n\n\n\n\n";
   }
   closedir(DIR);
}

