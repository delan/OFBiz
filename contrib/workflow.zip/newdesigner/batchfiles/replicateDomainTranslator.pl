         
         $rootdir = "c:\\workflow\\newdesigner\\src";
         $source = "$rootdir\\DomainTranslator.java";
         $destination = "$rootdir\\CompartmentTranslator.java";
         
         open(SOURCE, "< $source")
         or die "Couldn't open $source for reading: $!\n";
         
         chmod(0666, $destination);
         open(DESTINATION, "> $destination")
         or die "Couldn't open $destination for writing: $!\n";
         
         
         print DESTINATION "//WARNING !! DO NOT MODIFY THIS FILE\n";
         print DESTINATION "//THIS FILE IS GENERATED VIA SCRIPT\n";
         print DESTINATION "//MODIFY $source INSTEAD\n\n\n";
         
         $skip = "false";
         while (<SOURCE>) {
         	if ( /PL_STARTSKIP/) {
         		($skip eq "true") and die "skip already started";
         		$skip = "true";
         		next;
         	}
         	if ( /PL_STOPSKIP/) {
         		($skip eq "false") and die "skip already stopped";
         		$skip = "false";
         		next;
         	}
         	($skip eq "true") and next;
         
         	s/(^\s*class\s*)Domain(Translator\s*extends\s*BaseTranslator\s*{)/\1Compartment\2/;

         	s/(^\s*public\s*)Domain(Translator\(INetworkEditorModelWrapper\s*model,\s*)IDomainWrapper\s*domainWrapper(,\s*String\s*mode\)\s*{)/\1Compartment\2ICompartmentWrapper compartment\3/;
         	s/(super\(model, )domainWrapper(\);)/\1compartment\2/;
         	s/(public I)Domain(Wrapper )domain(\(\){)/\1Compartment\2compartment\3/;
         	s/(return \(I)Domain(Wrapper\)getDataObject\(\));/\1Compartment\2;/;
         	s/\bdomain\(\)/compartment\(\)/g;
         
         	print DESTINATION;
         
         	if (/public void updateDataImpl\(\){/) {
         		$tab = $_;
         		$tab =~ s/(^\s*)p(.*$)/\1/;
         		chomp ($tab);
         		print DESTINATION "$tab\tString modelName = model().getDisplayName();\n";
         		print DESTINATION "$tab\tString dataName = compartment().getNameAttribute();\n";
         		print DESTINATION "$tab\tif (!match(modelName, dataName))\n";
         		print DESTINATION "$tab\t\tcompartment().setNameAttribute(modelName);\n\n";
         	}
         	if (/public void updateModelImpl\(\){/) {
         		$tab = $_;
         		$tab =~ s/(^\s*)p(.*$)/\1/;
         		chomp ($tab);
         		print DESTINATION "$tab\tString modelName = model().getDisplayName();\n";
         		print DESTINATION "$tab\tString dataName = compartment().getNameAttribute();\n";
         		print DESTINATION "$tab\tif (!match(modelName, dataName))\n";
         		print DESTINATION "$tab\t\tmodel().setDisplayName(dataName);\n\n";
         	}
         }
         
         close DESTINATION;
         chmod(0000, $destination);
