         
         
         $rootdir = "c:\\workflow\\newdesigner";               
         chdir ($rootdir) or die "could not go to $rootdir";
         
         countFiles("$rootdir\\modified");
         countFiles("$rootdir\\src");
         countFiles("$rootdir\\src\\dataeditor");
         countFiles("$rootdir\\dxml");
         countFiles("$rootdir\\wrapper");
         
         #
         #subroutines
         #
         
         sub countFiles {
            my $dir = $_[0];
            $dirname = $dir;
            $dirname =~ s/.*\\(.*)/\1/;
            $count;

            chdir ("$dir") or die "could not go to $dir";
            system("dir /s/b *.java > files.txt");
            open(SOURCE, "< files.txt") or die "could not open files.txt for reading";
            while (<SOURCE>) {
            	open(FILE, "< $_") or die " could not open $_ for reading";
                chomp;
                $thisfile = $_;
                $thisfile =~ s/.*\\(.*)/\1/;
                $localcount = 0;
            	while (<FILE>) { 
                   $count++;
                   $localcount++;
                }
                #print "$localcount        lines in $thisfile\n";
            }
            print "count for $dirname is $count\n";
         }
