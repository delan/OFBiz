   # program to remove modified support class files from the generated wrapper directory

    defined($ARGV[0]) || die "specify dtd name as argument";
    $packagename=$ARGV[0];

   print "packagename is $packagename\n";

   $rootdir = "c:\\workflow\\newdesigner";
   $modifieddirname = "$rootdir\\modified\\$packagename";
   $wrapperdirname = "$rootdir\\wrapper\\$packagename";

   chdir ("$modifieddirname") or die "could not change to directory $modifieddirname";
   opendir(DIR, ".");
   print "1\n";
   @modifiedFiles = readdir(DIR);
   #create a hashtable of files
   foreach (@modifiedFiles) {
      	$fileSet{$_} = "1";
   }
   chdir ($wrapperdirname) or die "could not change to directory $wrapperdirname";
   opendir(DIR, ".");
   @files = readdir(DIR);
   foreach (@files){
      	/SupportClass.java/ or next; # skip non-supportclass files
        defined($fileSet{$_}) or next;
        print "***** deleting file $_\n";
        system "del $_";
   }


   die "program finished";

