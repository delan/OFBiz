$srcroot = "c:/workflow/specfiles";
$javacstr = "c:/java/jdk1.3/bin/javac";
$cpstr = "-classpath $targetdir;c:/workflow/classes";
$rmicstr = "c:/java/jdk1.3/bin/rmic";

@startdir = ($srcroot);

use File::Find;
sub process_file {
	/.java$/ && ($dirhash{$File::Find::dir} = "nothing");
}

find(\&process_file, @startdir);

foreach(keys %dirhash) {
	$dirstr .= "$_/*.java ";
}

$execstr = "$javacstr $cpstr $targetstr $dirstr";
system("cls");
print("$execstr\n\n\n");
system($execstr);