      
      $rootdir = "c:\\workflow\\newdesigner";
      $xmldir = "$rootdir\\xml";
      $dtddir = "$rootdir\\dtd";
      $taskxml = "$xmldir\\task\\DEMO2level.xml";
      $domainxml = "$xmldir\\domainenv\\DefaultDomain.xml";
      $gifdir = "$rootdir\\gif";
      $taskname = "DEMO2level";
      system("cls");
      #system("rd /s/q c:\\workflow\\public_html\\specfiles\\workflows\\FinalTest");
      #system("rd /s/q c:\\workflow\\public_html\\specfiles\\workflows\\NonTransactionalWF0");
	print "HAHAHA\n";

      system ("echo java -DGIFDIR=$gifdir -DWF_XMLDIR=$xmldir -DWF_DTDDIR=$dtddir  newdesigner.NetworkEditor $taskxml $taskname $domainxml");
      system ("java -DGIFDIR=$gifdir -DWF_XMLDIR=$xmldir -DWF_DTDDIR=$dtddir  newdesigner.NetworkEditor $taskxml $taskname $domainxml");
	print "DONEDONEDONE\n";
      
