         
         @dtds = ("dataclass", "roledomain", "networkdesign", "domainenv");
         foreach (@dtds) {
		print "perl xmake.pl $_\n";
         	system ("perl xmake.pl $_");
         }

         system ("perl compileAllNewDesigner.pl");
         
