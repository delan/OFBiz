
   $rootdir = "c:\\workflow\\newdesigner";
   $xmldir = "$rootdir\\xml";
   $dtddir = "$rootdir\\dtd";
   $taskxml = "$xmldir\\task\\NewDemo2.xml";
   $domainxml = "$xmldir\\domainenv\\DefaultDomain.xml";
   $gifdir = "$rootdir\\gif";
   $taskname = "NewDemo2";
   system("cls");
   system ("java -DGIFDIR=$gifdir -DWF_XMLDIR=$xmldir -DWF_DTDDIR=$dtddir  newdesigner.NetworkEditor $taskxml $taskname $domainxml");
