
   # SIMPLE FILTER PROGRAM
   #
   # filter <cmd> <filter>
   #
   # FIRST ARGUMENT IS EXECUTED
   # LINES IN STDERR CONTAINING FILTER IS REMOVED
   #

   $tmpfile = "tmp.tmp.tmp";
   die "no command specified as first argument" unless defined ($cmd = $ARGV[0]);
   die "no filter specified as second argument" unless defined ($filter = $ARGV[1]);
   system ("$cmd 2> $tmpfile");
   open (SRC, "< $tmpfile");
   while (<SRC>) {                                                                                                         
      print unless /$filter/ ;
   }

   unlink($tmpfile);
