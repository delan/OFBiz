
$source = "C:\\workflow\\public_html\\SpecFiles2\\workflows\\DEMO2level\\config";
$destination = "$source.tmp";

open(SOURCE, "< $source")
or die "Couldn't open $source for reading: $!\n";
open(DESTINATION, "> $destination")
or die "Couldn't open $destination for writing: $!\n";


while (<SOURCE>) {
	s/5000/4000/;
	print DESTINATION;
}

close DESTINATION;
system ("copy /y $destination $source");
system ("del $destination");

