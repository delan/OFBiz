      
      #REPLACE TERMINAL XML ELEMENTS WITH THE MORE ELEGANT ONE-LINE FORMAT
      
      $source = `cd`;
      chomp $source;
      #$source .= "\\$ARGV[0]";
      $source = "c:\\workflow\\newdesigner\\xml\\task\\FinalTest.xml";
      $destination = $source.".tmp";
      
      open(SOURCE, "< $source") or die "Couldn't open $source for reading: $!\n";
      open(DESTINATION, "> $destination") or die "Couldn't open $destination for writing: $!\n";
      
      while (<SOURCE>) {
         if ($previousLine =~ /^\s*<\S*\u.*>\s*/){
            $temp = $previousLine;
            $temp =~ s/^\s*<(\S*)\u.*>\s*/\1/;
            
            if (/^\s*<\/$temp>.*/) {
               $previousLine =~ s/>/\/>/;
               $_="";
            }
         }
        
         print DESTINATION $previousLine;
         $previousLine=$_;
      }
      print DESTINATION $previousLine;
      close DESTINATION;
   
      system("copy $destination $source");     
      system("del $destination");