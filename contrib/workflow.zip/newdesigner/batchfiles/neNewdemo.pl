
   system ("rd /s/q C:\\workflow\\public_html\\SpecFiles\\workflows\\");
   system (" md C:\\workflow\\public_html\\SpecFiles\\workflows\\");
   $rootdir = "c:\\workflow\\newdesigner";
   $xmldir = "$rootdir\\xml";
   $dtddir = "$rootdir\\dtd";
   $taskxml = "$xmldir\\task\\NewDemo.xml";
   $domainxml = "$xmldir\\domainenv\\DefaultDomain.xml";
   $gifdir = "$rootdir\\gif";
   $taskname = "NewDemo";
   system("cls");
   system ("java -DGIFDIR=$gifdir -DWF_XMLDIR=$xmldir -DWF_DTDDIR=$dtddir  newdesigner.NetworkEditor $taskxml $taskname $domainxml");
