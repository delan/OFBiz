
         defined($ARGV[0]) || die "specify filename(s) as argument";
         $files=$ARGV[0];

         $root = "c:/workflow/newdesigner";
         $jvc = "C:/Program Files/Microsoft Visual Studio/VJ98/jvc";
         $jdklib = "/workflow/classes;/jdk1.3/jre/lib/rt.jar;";
         $dxmllib = "/dxml/lib/dxml.jar;";
         $xml4jlib = "/workflow/classes/xml4j.jar";
         $outputdir = "\\workflow\\classes";
         
         $classpath = $jdklib.$dxmllib.$xml4jlib;
         $jvc = "\"$jvc\"";
         $jvcparams = "/g:l /cp $classpath /d $outputdir";
         $execstr = "$jvc $jvcparams $files";
         print "$execstr\n";
         system($execstr);
         
