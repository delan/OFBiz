    
   &quit_catcher;   
   &quit_catcher2("hi");   
   &quit_catcher3;   
   sub quit_catcher {
      print "hello world\n";
   }
      
sub AUTOLOAD {
   print "undefined subroutine $AUTOLOAD  \n";
}
