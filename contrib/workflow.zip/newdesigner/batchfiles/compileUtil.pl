         
         $jvc = "\"C:\\Program Files\\Microsoft Visual Studio\\VJ98\\jvc\"";
	 $rootdir="C:\\workflow\\util";
         $outputdir="c:\\workflow\\classes";
         $classpath = "C:\\dxml\\lib\\dxml.jar;C:\\workflow\\classes\\xml4j.jar;$outputdir;c:\\jdk1.3\\jre\\lib\\rt.jar";
         $jvcparams = "/g:l /cp $classpath /d $outputdir";
         $srcroot = $rootdir."/src";

         system("rd /s/Q $outputdir\\util");
         $execstr = "$rootdir\\*.java";
         $execstr = "$jvc $jvcparams $execstr";
         print "$execstr\n";
         system($execstr);

