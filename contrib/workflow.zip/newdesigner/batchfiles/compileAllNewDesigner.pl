            
            $jvc = "\"C:\\Program Files\\Microsoft Visual Studio\\VJ98\\jvc\"";
            $rootdir="C:\\workflow\\newdesigner";
            $outputdir="c:\\workflow\\classes";
            $classpath = "C:\\dxml\\lib\\dxml.jar;C:\\workflow\\classes\\xml4j.jar;$outputdir;c:\\jdk1.3\\jre\\lib\\rt.jar";
            
            $jvcparams = "/g:l /cp $classpath /d $outputdir";
            $srcroot = $rootdir."/src";
            
            @dataroots = ("dxml",  "wrapper", "modified");
            @dtds = ("dataclass", "roledomain", "networkdesign", "domainenv");
            @srcs = ("latticeeditor", "latticeeditor\\model", "dataeditor", "dataeditor\\model", "model", "operatoreditor", "popup", "");
            
            foreach (@dataroots){ $_ = "$rootdir/$_";}
            
            system ("rd /s/Q $outputdir\\newdesigner");
            system ("rd /s/Q $outputdir\\latticeeditor");
            system ("rd /s/Q $outputdir\\dataeditor");
            foreach $dtd (@dtds) {
            	system ("rd /s/Q $outputdir\\$dtd");
            	foreach (@dataroots) { $execstr .= " $_\\$dtd\\*.java";}
            }
            foreach (@srcs) {  $execstr .= " $srcroot\\$_\\*.java";}
            
            
            $execstr = "$jvc $jvcparams $execstr";
            print "$execstr\n";
            system($execstr);
            
