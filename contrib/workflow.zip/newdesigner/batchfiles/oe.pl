
   $rootdir = "c:\\workflow\\newdesigner";
   $xmldir = "$rootdir\\xml";
   $dtddir = "$rootdir\\dtd";
   $taskxml = "$xmldir\\task\\FinalTest.xml";
   $domainxml = "$xmldir\\domainenv\\DefaultDomain.xml";
   $gifdir = "$rootdir\\gif";
   $taskname = "FinalTest";
   system("cls");
   system ("java -DGIFDIR=$gifdir -DWF_XMLDIR=$xmldir -DWF_DTDDIR=$dtddir  newdesigner.operatoreditor.OperatorEditor $taskxml NonTransactional2 OUTPUT_OPERATOR");
