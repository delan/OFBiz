

   # this script converts all task-ids and corresponding references  to the (more readable) task-names   
   $inputfile = "c:\\workflow\\newdesigner\\xml\\task\\NewDemo.xml";
   $outputfile = $inputfile.".tmp";
   
   open(INPUTFILE, "< $inputfile") or die " could not open $inputfile";
   open(OUTPUTFILE, "> $outputfile") or die " could not open $outputfile";
   
   while (<INPUTFILE>) {
      if (/<Task/) {
         ($id = $_) =~ s/^.*\sid="([^"]*)".*$/\1/;
         ($name = $_) =~ s/^.*\sname="([^"]*)".*$/\1/;
         if (defined $table{$id}) { die " id : $table{$id} defined more than once"; }
         $table{$id} = $name;
      }
   }

   open(INPUTFILE, "< $inputfile") or die "could not open $inputfile";
   while (<INPUTFILE>) {
      @ids = keys(%table);
      $line = $_;
      foreach $id (@ids){
         $name = $table{$id};
         chomp $id; chomp $name;
         $line =~ s/$id/$name/;
      }
      print OUTPUTFILE $line;
   }

   close ($inputfile);
   close ($outputfile);

   system ("copy /y $outputfile $inputfile");
