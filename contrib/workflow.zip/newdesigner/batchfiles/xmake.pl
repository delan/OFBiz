   
   die "specify dtd name as argument" unless defined($ARGV[0]);
   ($packagename=$ARGV[0]) =~ s/.dtd//;

   $xgen = "c:\\dxml\\bin\\xgen.exe";
   $rootdir = "c:\\workflow\\newdesigner";
   
   die "XGEN not defined \n" unless (defined $xgen) ;
   die "rootdir not defined \n" unless (defined $rootdir)	;
   

   $dtddir = $rootdir."\\dtd";
   $dxmldir = $rootdir."\\dxml";
   $wrapperdir = $rootdir."\\wrapper";
   $modifieddir = $rootdir."\\modified";

   if (chdir("$dxmldir\\$packagename")) {
   	print "directory $dxmldir\\$packagename exists, deleting\n";
   	chdir ("..");
   	system("rd /s/q $packagename");
   }
   if (chdir ("$wrapperdir\\$packagename")) {
   	print "directory $wrapperdir\\$packagename exists, deleting\n";
   	chdir ("..");
   	system("rd /s/q $packagename");
   }
   system ("$xgen -d $dxmldir $dtddir\\$packagename.dtd \n");
   chdir ("$dxmldir\\$packagename") or die "couldn't change to directory $dxmldir\\$packagename\n";
   opendir(DIR, ".");
   @files = readdir(DIR);
   
   #create a hashtable of files
   $fileSet{$_} = "1" foreach (@files);
   foreach (@files) {
   	/.java/ or next; # skip non-java files
   	(/Factory.java/ || /DocumentTypeInfo.java/ || /IEntities.java/) and next;  # skip these files
   	$root = $_;
   #check to see if the file is an interface, if so skip
   	if (/^I/) {
   		$root =~ s/^.//;
        defined($fileSet{$root}) and next;
   		$root = $_;
   	}
   	generateAllWrappers($root);
   }
   
   chdir($wrapperdir);
   mkdir($packagename, 0777)  or die "*** WARNING: Directory $wrapperdir\\$packagename already exists\n";
   
   system "xcopy /Y $dxmldir\\$packagename\\*Wrapper.java $wrapperdir\\$packagename";
   system "xcopy /Y $dxmldir\\$packagename\\*SupportClass.java $wrapperdir\\$packagename";
   system "del $dxmldir\\$packagename\\*Wrapper.java";
   system "del $dxmldir\\$packagename\\*SupportClass.java";
   removeModifiedClasses($wrapperdir, $modifieddir, $packagename);
   
   #
   #subroutines
   #
   
   sub generateAllWrappers {
   	my $root = $_[0];
   	$root =~ s/.java$//;
   generateIWrapper($root);
   	generateISupportClass($root);
   	generateSupportClass($root);
   }
   
   sub generateIWrapper {
   	my $file = $_[0];
   	$file =~ s/^(.*)$/I\1Wrapper/;
   	print "saving $file .java\n";
   	open (FILE,"> $file.java");
   	print FILE "package $packagename; \n\npublic interface $file extends I$_[0], I$_[0]SupportClass, pattern.IRegistrar {\n}\n";
   	close (FILE);
   }
   
   sub generateSupportClass {
   	my $file = $_[0];
   	$file =~ s/$/SupportClass/;
   	print "saving $file.java\n";
   	open (FILE,"> $file.java");
   	print FILE "package $packagename; \n\nimport pattern.*;\n\n";
   	print FILE "//\n// IMPORTANT NOTE !!\n// call notifyDataModified(), notifyElementAdded() or notifyElementRemoved() as appropriate \n// after making *changes* to dtd object\n//\n\n";
   	print FILE "public class $file extends AbstractDataSupportClass implements I$file {\n}\n";
   	close (FILE);
   }
   
   sub generateISupportClass {
   	my $file = $_[0];
   	$file =~ s/^(.*)$/I\1SupportClass/;
   	print "saving $file.java\n";
   	open (FILE,"> $file.java");
   	print FILE "package $packagename;    \n\nimport pattern.*;\n\npublic interface $file extends IDataSupportClass {\n}\n";
   	close (FILE);
   }
   
   sub removeModifiedClasses {
    my ($wrapperdir, $modifieddir, $packagename) = @_;
   	print "wrapperdir is $wrapperdir\n";
   	print "modifieddir is $modifieddir\n";
   	chdir ("$modifieddir\\$packagename") or die "could not change to directory $modifieddir\\$packagename\n";
   	opendir(DIR, ".");
   	@modifiedfiles = readdir(DIR);
   	$fileset{$_} = "1" foreach (@modifiedfiles) ;
   	chdir ("$wrapperdir\\$packagename") or die "could not change to directory $wrapperdir\\$packagename";
   	opendir(DIR, ".");
   	@files = readdir(DIR);
   	foreach (@files) {
   		/SupportClass.java/ or next; # skip non-supportclass files
   		defined($fileset{$_}) or next;
   		print "***** deleting file $_\n";
   		system "del $_";
   	}
   }
