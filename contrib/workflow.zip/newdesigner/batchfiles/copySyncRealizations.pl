
   $srcDir = "c:\\workflow\\public_html";
   $destDir = "c:\\workflow\\public_html";

   system ("copy $srcDir\\s_sync_reviewplan_logistics.java $destDir\\SpecFiles\\workflows\\DEMO2level\\Sync_ReviewPlan_Logistics\\Realization.java");
   system ("copy $srcDir\\s_sync_logistics_finalreview.java $destDir\\SpecFiles\\workflows\\DEMO2level\\Sync_Logistics_FinalReview\\Realization.java");
   system ("copy $srcDir\\u_sync_reviewplan_logistics.java $destDir\\SpecFiles2\\workflows\\DEMO2level\\Sync_ReviewPlan_Logistics\\Realization.java");
   system ("copy $srcDir\\u_sync_logistics_finalreview.java $destDir\\SpecFiles2\\workflows\\DEMO2level\\Sync_Logistics_FinalReview\\Realization.java");

