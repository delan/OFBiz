
   $sourcepath = "c:\\workflow\\newdesigner\\src";                                                                            
   $classpath = "c:\\workflow\\classes";                                                                            

   system ("java -DNOINFO -DPARSER_SOURCEPATH=$sourcepath -DPARSER_CLASSPATH=$classpath util.CodeParser");
                                                                            
