use File::Find;
@ARGV = ('.') unless @ARGV;
#my $sum = 0;
find sub { /.java/ && system("jvc /d \\workflow\\classes $_")}, @ARGV;
