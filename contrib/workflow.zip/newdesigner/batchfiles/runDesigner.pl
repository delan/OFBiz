$srcroot = "c:/workflow";
$javastr = "c:/java/jdk1.3/bin/java";
$cpstr = "-classpath $srcroot/classes;$srcroot/lib/dxml.jar;$srcroot/lib/xml4j.jar"; 


$newddir = "$srcroot/newdesigner";
$xmldir = "$newddir/xml";
$dtddir = "$newddir/dtd";
$taskxml = "$xmldir/task/testdb.xml";
$domainxml = "$xmldir/domainenv/DefaultDomain.xml";
$gifdir = "$newddir/gif";
$taskname = "testdb";

system("cls");

$execstr = "$javastr $cpstr -DGIFDIR=$gifdir -DWF_XMLDIR=$xmldir -DWF_DTDDIR=$dtddir  newdesigner.NetworkEditor $taskxml $taskname $domainxml";
print($execstr);
system($execstr);
      
