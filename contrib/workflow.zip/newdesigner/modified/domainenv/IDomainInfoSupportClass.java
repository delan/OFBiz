package domainenv;    

import pattern.*;

public interface IDomainInfoSupportClass extends IDataSupportClass {
	public java.awt.Color getAWTColor();
}
