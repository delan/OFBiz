package dataclass;    

import pattern.*;

public interface IFieldListSupportClass extends IDataSupportClass {
	public IField createField();
	public IField getField(String name);
}
