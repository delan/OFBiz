package dataclass;    

import pattern.*;

public interface IParametersListSupportClass extends IDataSupportClass {
	public IParameter createParameter();
	public IParameter getParameter(String name);
}
