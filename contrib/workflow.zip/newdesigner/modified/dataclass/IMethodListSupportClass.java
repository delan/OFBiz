package dataclass;    

import pattern.*;

public interface IMethodListSupportClass extends IDataSupportClass {
	public IMethod createMethod();
	public IMethod getMethod(String name);
}
