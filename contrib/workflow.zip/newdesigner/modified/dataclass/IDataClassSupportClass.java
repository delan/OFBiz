package dataclass;    

import pattern.*;

public interface IDataClassSupportClass extends IDataSupportClass {
	public IParent createParent();
}
