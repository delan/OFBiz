package dataclass;    

import pattern.*;

public interface IMethodSupportClass extends IDataSupportClass {
	public boolean containsException(String name);
}
