package dataclass;    

import pattern.*;

public interface ITypeSupportClass extends IDataSupportClass {
	public String toString();
	public void parseAndSet(String typeStr);
}
