package roledomain;    

import pattern.*;

public interface IRoleDomainSupportClass extends IDataSupportClass {
	public IRole createRole(String id);
	public IRoleRelationship createRoleRelationship(String id);
}
