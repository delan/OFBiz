package networkdesign;    

import pattern.*;

public interface ITaskExceptionSupportClass extends IDataSupportClass {
    public ILocalHandler createLocalHandler();
}
