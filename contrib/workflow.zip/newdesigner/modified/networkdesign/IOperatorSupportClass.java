package networkdesign;    

import pattern.*;

public interface IOperatorSupportClass extends IDataSupportClass {
    IField createField(String fieldID);
}
