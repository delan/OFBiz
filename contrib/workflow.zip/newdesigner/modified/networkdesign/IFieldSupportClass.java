package networkdesign;    

import pattern.*;

public interface IFieldSupportClass extends IDataSupportClass {
    IOperator createOperator(String opID);
    public void setTaskAttributeByName(String taskName);
}
