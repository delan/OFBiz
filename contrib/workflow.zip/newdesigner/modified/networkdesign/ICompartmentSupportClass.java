package networkdesign;    

import pattern.*;

public interface ICompartmentSupportClass extends IDataSupportClass {
    public ICompartment createCompartment(String ID);
    public void setUrlAttribute(String modelURL);
}
