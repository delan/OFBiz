package networkdesign;    

import pattern.*;
import java.util.*;

public interface ITransactionalTaskRealizationSupportClass extends IDataSupportClass {
    public Vector getInputNames();
    public Vector getOutputNames();
}
