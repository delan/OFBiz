package networkdesign;    

import pattern.*;

public interface IInputMappingListSupportClass extends IDataSupportClass {
    public void addMappingByParameterID(String sourceID, String destinationID) ;
}
