package networkdesign;    

import pattern.*;

public interface IOutputMappingListSupportClass extends IDataSupportClass {
    public void addMappingByParameterID(String sourceID, String destinationID) ;
}
