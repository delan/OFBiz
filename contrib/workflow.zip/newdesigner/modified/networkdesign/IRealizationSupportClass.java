package networkdesign;    

import pattern.*;

public interface IRealizationSupportClass extends IDataSupportClass {
	public void createSimpleRealization(String realizationType);
	public void createNetworkRealization(String realizationType);
}
