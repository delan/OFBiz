package networkdesign;    

import pattern.*;

public interface IRolesSupportClass extends IDataSupportClass {
	void createNewRole(String selectedRole);
	void removeRole(String selectedRole);
}
