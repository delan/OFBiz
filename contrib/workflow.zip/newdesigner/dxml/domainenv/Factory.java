/**
 * Factory.java	Java 1.3.0 Fri Apr 27 15:06:33 EDT 2001
 *
 * Copyright 1999 by ObjectSpace, Inc.,
 * 14850 Quorum Dr., Dallas, TX, 75240 U.S.A.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information
 * of ObjectSpace, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with ObjectSpace.
 */

package domainenv;

public class Factory
  {
  public static IPosition newPosition()
    {
    return new domainenv.Position();
    }

  public static IDomainInfo newDomainInfo()
    {
    return new domainenv.DomainInfo();
    }

  public static IDomainRelationship newDomainRelationship()
    {
    return new domainenv.DomainRelationship();
    }

  public static IDomainEnv newDomainEnv()
    {
    return new domainenv.DomainEnv();
    }

  public static IPolicyRecord newPolicyRecord()
    {
    return new domainenv.PolicyRecord();
    }

  public static IColor newColor()
    {
    return new domainenv.Color();
    }

  }