/**
 * Factory.java	Java 1.3.0 Fri Apr 27 15:06:28 EDT 2001
 *
 * Copyright 1999 by ObjectSpace, Inc.,
 * 14850 Quorum Dr., Dallas, TX, 75240 U.S.A.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information
 * of ObjectSpace, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with ObjectSpace.
 */

package networkdesign;

public class Factory
  {
  public static IInputMappingList newInputMappingList()
    {
    return new networkdesign.InputMappingList();
    }

  public static IOutput newOutput()
    {
    return new networkdesign.Output();
    }

  public static ICorbaMapping newCorbaMapping()
    {
    return new networkdesign.CorbaMapping();
    }

  public static IParameter newParameter()
    {
    return new networkdesign.Parameter();
    }

  public static IOutputOperator newOutputOperator()
    {
    return new networkdesign.OutputOperator();
    }

  public static ISimpleRealization newSimpleRealization()
    {
    return new networkdesign.SimpleRealization();
    }

  public static ITaskException newTaskException()
    {
    return new networkdesign.TaskException();
    }

  public static IDataSecurityMask newDataSecurityMask()
    {
    return new networkdesign.DataSecurityMask();
    }

  public static IInvocation newInvocation()
    {
    return new networkdesign.Invocation();
    }

  public static ICorbaInvocation newCorbaInvocation()
    {
    return new networkdesign.CorbaInvocation();
    }

  public static IPumpBoundaryInfo newPumpBoundaryInfo()
    {
    return new networkdesign.PumpBoundaryInfo();
    }

  public static IArc newArc()
    {
    return new networkdesign.Arc();
    }

  public static IOutputMappingList newOutputMappingList()
    {
    return new networkdesign.OutputMappingList();
    }

  public static ILocalHandler newLocalHandler()
    {
    return new networkdesign.LocalHandler();
    }

  public static IReverseMappingList newReverseMappingList()
    {
    return new networkdesign.ReverseMappingList();
    }

  public static IRealization newRealization()
    {
    return new networkdesign.Realization();
    }

  public static IOperator newOperator()
    {
    return new networkdesign.Operator();
    }

  public static ITransactionalTaskRealization newTransactionalTaskRealization()
    {
    return new networkdesign.TransactionalTaskRealization();
    }

  public static IFieldMask newFieldMask()
    {
    return new networkdesign.FieldMask();
    }

  public static INonTransactionalTaskRealization newNonTransactionalTaskRealization()
    {
    return new networkdesign.NonTransactionalTaskRealization();
    }

  public static IForwardMappingList newForwardMappingList()
    {
    return new networkdesign.ForwardMappingList();
    }

  public static INetworkTaskRealization newNetworkTaskRealization()
    {
    return new networkdesign.NetworkTaskRealization();
    }

  public static IInputOperator newInputOperator()
    {
    return new networkdesign.InputOperator();
    }

  public static IGenericBoundaryInfo newGenericBoundaryInfo()
    {
    return new networkdesign.GenericBoundaryInfo();
    }

  public static IMapping newMapping()
    {
    return new networkdesign.Mapping();
    }

  public static IRoles newRoles()
    {
    return new networkdesign.Roles();
    }

  public static IRole newRole()
    {
    return new networkdesign.Role();
    }

  public static ITask newTask()
    {
    return new networkdesign.Task();
    }

  public static ICollaborationObject newCollaborationObject()
    {
    return new networkdesign.CollaborationObject();
    }

  public static INetworkDesign newNetworkDesign()
    {
    return new networkdesign.NetworkDesign();
    }

  public static IBoundaryInfo newBoundaryInfo()
    {
    return new networkdesign.BoundaryInfo();
    }

  public static ICompartment newCompartment()
    {
    return new networkdesign.Compartment();
    }

  public static ISyncRealization newSyncRealization()
    {
    return new networkdesign.SyncRealization();
    }

  public static IDomain newDomain()
    {
    return new networkdesign.Domain();
    }

  public static IHumanRealization newHumanRealization()
    {
    return new networkdesign.HumanRealization();
    }

  public static ICollaborationRealization newCollaborationRealization()
    {
    return new networkdesign.CollaborationRealization();
    }

  public static IField newField()
    {
    return new networkdesign.Field();
    }

  }