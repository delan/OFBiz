/**
 * INonTransactionalTaskRealization.java	Java 1.3.0 Fri Apr 27 15:06:28 EDT 2001
 *
 * Copyright 1999 by ObjectSpace, Inc.,
 * 14850 Quorum Dr., Dallas, TX, 75240 U.S.A.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information
 * of ObjectSpace, Inc. ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with ObjectSpace.
 */

package networkdesign;

import java.util.Hashtable;

public interface INonTransactionalTaskRealization extends com.objectspace.xml.IDXMLInterface ,com.objectspace.xml.IAttributeContainer
  {

  // element Attributes
  public String getTypeAttribute();
  public void setTypeAttribute( String value );
  public String removeTypeAttribute();

  // element TaskInvocation
  public String getTaskInvocation();
  public void setTaskInvocation( String arg0 );

  // element CorbaInvocation
  public ICorbaInvocation getCorbaInvocation();
  public void setCorbaInvocation( ICorbaInvocation arg0 );
  }