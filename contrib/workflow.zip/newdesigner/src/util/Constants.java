package util;

import javax.swing.*;

public class Constants{
	public static final String REDRAW_MENU = "RedrawMenu";
	public static final String COMBO_BOX_CHANGED = new JComboBox().getActionCommand();
}
