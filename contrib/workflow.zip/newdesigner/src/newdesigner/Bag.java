package newdesigner;

import generic.*;
import pattern.*;
import networkdesign.*;
import java.util.*;
import util.*;

public class Bag {
    IDocument nameFieldModel, descriptionFieldModel, hostFieldModel, timeoutFieldModel, compartmentsFieldModel;
    IListModel currentRolesFieldModel, availableRolesFieldModel, inputArcsFieldModel, outputArcsFieldModel, exceptionArcsFieldModel, invocationsFieldModel, outputsFieldModel, exceptionsFieldModel, constraintsFieldModel;
    IComboBoxModel taskTypeFieldModel, securityDomainFieldModel, roleDomainFieldModel;
    ICheckBoxModel foreignFieldModel;
}


class AvailableRolesTranslator extends BaseTranslator {
    Hashtable allRoledomainXmls;

    public AvailableRolesTranslator(IListWrapper modelIn, IRolesWrapper wrapperIn, Hashtable allRoledomainXmlsIn, String mode) {
        super(modelIn, wrapperIn);
        allRoledomainXmls = allRoledomainXmlsIn;
        synchronize(mode);
    }

    public void updateModelImpl() {
        IListModel model = (IListModel)getGuiModel();

        while(model.getSize() > 0)
            model.remove(0);

        IRoles wrapper = (IRoles)getDataObject();
        String href = wrapper.getRoledomainAttribute();
        XmlWrapper roledomainXml = (XmlWrapper)allRoledomainXmls.get(href);
        roledomain.IRoleDomainWrapper roleDomain = (roledomain.IRoleDomainWrapper)roledomainXml.getRoot();

        HashSet currentRoles = new HashSet();
        for(int i = 0; i < wrapper.getRoleCount(); i++) {
            String roleHref = wrapper.getRoleAt(i).getUrlAttribute();
            int index = roleHref.indexOf("#");
            String name = roleHref.substring(index+1, roleHref.length());
            currentRoles.add(name);
        }

        int index = 0;
        for(int i = 0; i < roleDomain.getRoleCount(); i++) {
            String roleName = roleDomain.getRoleAt(i).getName();
            if(!currentRoles.contains(roleName)) {
                model.insertElementAt(roleName, index++);
            }
        }
    }

    public void updateDataImpl() {
        IListModel model = (IListModel)getGuiModel();
        WARNING.println("NOT IMPLEMENTED");
    }   
}

class SecurityDomainTranslator extends BaseTranslator {
    Hashtable allSecurityDomains;   

    public SecurityDomainTranslator(IComboBoxWrapper modelIn, ITaskWrapper taskWrapperIn, Hashtable allSecurityDomainsIn, String mode) {
        super(modelIn, taskWrapperIn);
        allSecurityDomains = allSecurityDomainsIn;
        synchronize(mode);
    }

    public void updateModelImpl() {
        IComboBoxModel model = (IComboBoxModel)getGuiModel();
        ITaskWrapper taskWrapper = (ITaskWrapper)getDataObject();

        model.removeAllElements();
        String domain = taskWrapper.getSecuritydomainurlAttribute();
        int poundIndex = domain.indexOf("#");
        domain = domain.substring(poundIndex+1, domain.length());

        Enumeration keys = allSecurityDomains.keys();
        while(keys.hasMoreElements()) {
            String key = (String)keys.nextElement();
            model.addElement(key);
        }
        if(model.getIndexOf(domain) < 0)
            throw new RuntimeException("invalid domain " + domain);

        model.setSelectedItem(domain);
    }

    public void updateDataImpl() {
        IComboBoxModel model = (IComboBoxModel)getGuiModel();
        ITaskWrapper taskWrapper = (ITaskWrapper)getDataObject();

        String domain = (String)model.getSelectedItem();
        String href = taskWrapper.getSecuritydomainurlAttribute();
        int poundIndex = href.indexOf("#");
        domain = href.substring(0, poundIndex+1) + domain;

        if(!domain.equals(href)) 
            ((ITask)taskWrapper).setSecuritydomainurlAttribute(domain);
            //taskWrapper.setSecuritydomainurlAttribute(domain);
    }
}

class RoledomainTranslator extends BaseTranslator {
    public RoledomainTranslator(IComboBoxWrapper modelIn, ITaskWrapper taskWrapperIn, String mode) {
        super(modelIn, taskWrapperIn);
        synchronize(mode);
    }

    public void updateModelImpl() {
        IComboBoxModel model = (IComboBoxModel)getGuiModel();
        ITaskWrapper taskWrapper = (ITaskWrapper)getDataObject();

        model.removeAllElements();
        int count = 0;
        try {
            count = taskWrapper.getRolesCount();
        } catch(NullPointerException e) {
            return;
        }
        for(int i=0; i<count; i++) {
            String roleDomain = taskWrapper.getRolesAt(i).getRoledomainAttribute();
            model.insertElementAt(roleDomain, i);
        }
    }

    public void updateDataImpl() {
        WARNING.println("NOT IMPLEMENTED");
    }
}
