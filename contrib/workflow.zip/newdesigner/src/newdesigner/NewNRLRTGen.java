package newdesigner;


public class NewNRLRTGen extends BaseRTGenerator {

}
