package newdesigner.operatoreditor;

import java.awt.*;
import newdesigner.model.*;
import util.*;

class TaskComponent extends OperatorComponent {
    String taskName;

    public TaskComponent(IOperatorEditorPanelModel modelIn, String editorType) {
        super(modelIn.getStartingOperator(), editorType);
        taskName = modelIn.getTaskName();
    }

    public void paintComponent(Graphics g) {
        g.drawRect(0, 0, getWidth()-1, getHeight()-1);
        g.drawString(taskName, 10, getHeight()*3/4);
    }
}
