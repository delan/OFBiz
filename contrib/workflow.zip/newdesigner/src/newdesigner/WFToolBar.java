package newdesigner;

import java.awt.event.ActionListener;
import newdesigner.popup.*;
import util.AbstractToolBar;
import util.WFButtonComboBox;
import util.WFRadioButton;

public class WFToolBar extends AbstractToolBar{
	// each button is represented by an ordered triple
	// button title, tooltip, and ActionCommand
	String[][] buttonInfo =
	{
		{"Select", "select component", ActionEvents.SELECT},
				{COMBO_BOX, "add new domain", "Domain"},
				{COMBO_BOX, "add new task", "Task"},
				{COMBO_BOX, "add new workflow task", "WFTask"},
				{COMBO_BOX, "add new dataflow arc", "Arc"},
				{"Del", "delete selection", ActionEvents.DELETE},
				{"Help", "Map Editor help", ActionEvents.HELP_INDEX},
				{RADIO_BUTTON, "toggle fail arc display", "ShowFailArcs"}
	};

	public WFToolBar(){
		setData(buttonInfo);
	}

}




