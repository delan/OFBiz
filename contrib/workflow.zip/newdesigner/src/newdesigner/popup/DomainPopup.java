package newdesigner.popup;

import util.*;

public class DomainPopup extends WFPopup {
    // {label, actionCommand}
    static String[][] menuItemInfo = {
        //{"Insert", SUBMENU + "InsertCompartmentMenu"}, 
        {"Delete", ActionEvents.DELETE}, 
        {"Insert", SUBMENU +  "DomainInsertPopup"}, 
        {"", ActionEvents.SEPERATOR},
        {"View up", ActionEvents.VIEW_UP},
        //{"Domain Editor", ActionEvents.DOMAIN_ED},
        {"Properties", ActionEvents.LOCAL_DOMAIN_ED},
        {"Domain Editor", ActionEvents.DOMAIN_ED},
        //{"Find", ActionEvents.FIND},
        //  {"Help", ActionEvents.HELP_CONTEXT}
    };

    public DomainPopup() {
        super(menuItemInfo, "newdesigner.popup");
    }
}
