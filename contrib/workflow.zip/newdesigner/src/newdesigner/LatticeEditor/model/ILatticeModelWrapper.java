package latticeeditor.model;

import pattern.*;

public interface ILatticeModelWrapper extends ILatticeModel,IModelProxySupportClass {
}
