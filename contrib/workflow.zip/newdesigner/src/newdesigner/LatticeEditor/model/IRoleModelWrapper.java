package latticeeditor.model;

import pattern.*;

public interface IRoleModelWrapper extends IRoleModel,IModelProxySupportClass {
}
