package latticeeditor.model;

import pattern.*;

public interface IDomainModelWrapper extends IDomainModel, IModelProxySupportClass {
	
}
