package latticeeditor.model;

import pattern.*;


public interface IDomainEnvModelWrapper extends IDomainEnvModel,IModelProxySupportClass {
	
}
