package latticeeditor.model;

import pattern.*;

public interface ILatticeNodeModelWrapper extends ILatticeNodeModel,IModelProxySupportClass {
}
