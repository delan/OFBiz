package latticeeditor.model;

import pattern.*;

public interface ILatticeLinkModelWrapper extends ILatticeLinkModel,IModelProxySupportClass {
}
