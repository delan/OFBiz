package latticeeditor.model;

import pattern.*;
import generic.*;
import java.util.*;
import latticeeditor.*;
import java.awt.*;
import newdesigner.model.*;


public interface ILatticeModel extends IBaseModel {
	public ILatticeNodeModel addLatticeNode(Point aPos, String id);
	public void addLatticeNode(ILatticeNodeModel aModel);
	public ILatticeLinkModel addLatticeLink(ILatticeNodeModel high, ILatticeNodeModel low);
	public void addLatticeLink(ILatticeLinkModel aRelationship);
	//public void removeLatticeLink(ILatticeLinkModel removal) ;
	//public void removeLatticeNode(ILatticeNodeModel aDomain);
	public ILatticeNodeModel getLatticeNodeAt(int index);
	public ILatticeLinkModel getLatticeLinkAt(int index);
	public int getLatticeNodeCount();
	public int getLatticeLinkCount();
	public Hashtable latticeNodesHashedById();
	public Hashtable latticeLinksHashedById();
	public void removeRedundancy(ILatticeNodeModel low, ILatticeNodeModel high);
	public boolean checkAncestors(ILatticeNodeModel start, ILatticeNodeModel target);
	public String getId();
	public void setId(String newId);
	public String getName();
	public void setName(String newName);	
}
