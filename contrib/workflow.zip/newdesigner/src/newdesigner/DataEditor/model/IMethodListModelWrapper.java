package dataeditor.model;

import pattern.*;

public interface IMethodListModelWrapper extends IMethodListModel,IModelProxySupportClass {
}
