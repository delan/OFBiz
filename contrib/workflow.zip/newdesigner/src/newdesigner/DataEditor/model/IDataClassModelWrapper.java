package dataeditor.model;

import pattern.*;

public interface IDataClassModelWrapper extends IDataClassModel, IModelProxySupportClass {

}
