package dataeditor.model;

import pattern.*;

public interface IFieldListModelWrapper extends IFieldListModel, IModelProxySupportClass {
}
