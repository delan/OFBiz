package dataeditor.model;

import pattern.*;

public interface IExceptionListModelWrapper extends IExceptionListModel, IModelProxySupportClass
{
}
