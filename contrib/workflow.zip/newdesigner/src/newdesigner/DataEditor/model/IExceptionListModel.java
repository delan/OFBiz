package dataeditor.model;

import javax.swing.table.*;
import pattern.*;
import java.util.*;
import util.*;

public interface IExceptionListModel extends ITableModelWithRemoveRow,IGuiModel {
	public Vector addNewException(String name);
	public Vector getExceptions();
	public void removeException(Vector theException);
	public Vector getException(String name);
}

