package newdesigner.model;

import pattern.*;

public interface IOperatorModelWrapper extends IModelProxySupportClass, IOperatorModel{
}
