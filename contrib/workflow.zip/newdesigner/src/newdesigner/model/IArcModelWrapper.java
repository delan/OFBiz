package newdesigner.model;

import pattern.*;

public interface IArcModelWrapper extends IModelProxySupportClass, IArcModel{
}
