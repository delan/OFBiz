package newdesigner.model;

public final class OperatorEditorType {
    public static final String INPUT_OPERATOR = new String("INPUT_OPERATOR");
    public static final String OUTPUT_OPERATOR = new String("OUTPUT_OPERATOR");
}
