package newdesigner.model;

import pattern.*;

public interface IOperatorFieldWrapper extends IModelProxySupportClass, IOperatorField{
}
