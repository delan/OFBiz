package newdesigner.model;

public final class OperatorType{
	public static final String TASK = new String("TASK");
	public static final String AND_OPERATOR = new String("and");
	public static final String OR_OPERATOR = new String("or");
	public static final String LOOP_OPERATOR = new String("loop");
}

