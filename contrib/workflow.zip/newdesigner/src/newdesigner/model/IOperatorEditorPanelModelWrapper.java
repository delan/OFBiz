package newdesigner.model;

import pattern.*;

public interface IOperatorEditorPanelModelWrapper extends IModelProxySupportClass, IOperatorEditorPanelModel{
}
