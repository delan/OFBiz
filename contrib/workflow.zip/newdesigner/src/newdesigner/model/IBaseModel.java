package newdesigner.model;

import pattern.*;
import generic.*;

public interface IBaseModel extends IRelationshipNode, IModel, IGuiModel{
}
