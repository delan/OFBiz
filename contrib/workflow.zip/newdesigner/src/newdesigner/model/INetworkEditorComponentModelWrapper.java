package newdesigner.model;

import pattern.*;

public interface INetworkEditorComponentModelWrapper extends IModelProxySupportClass, INetworkEditorComponentModel{
}
