package newdesigner.model;

import pattern.*;

public interface IContainerModelWrapper extends IModelProxySupportClass, IContainerModel{
}
