package dataclass;    

import pattern.*;

public interface IParameterSupportClass extends IDataSupportClass {
}
