package dataclass; 

public interface IFieldWrapper extends IField, IFieldSupportClass, pattern.IRegistrar {
}
