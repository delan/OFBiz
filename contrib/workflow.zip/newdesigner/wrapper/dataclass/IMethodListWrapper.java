package dataclass; 

public interface IMethodListWrapper extends IMethodList, IMethodListSupportClass, pattern.IRegistrar {
}
