package dataclass; 

public interface IMethodWrapper extends IMethod, IMethodSupportClass, pattern.IRegistrar {
}
