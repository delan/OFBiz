package dataclass; 

public interface IDataClassWrapper extends IDataClass, IDataClassSupportClass, pattern.IRegistrar {
}
