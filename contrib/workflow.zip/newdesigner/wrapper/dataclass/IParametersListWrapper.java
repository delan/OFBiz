package dataclass; 

public interface IParametersListWrapper extends IParametersList, IParametersListSupportClass, pattern.IRegistrar {
}
