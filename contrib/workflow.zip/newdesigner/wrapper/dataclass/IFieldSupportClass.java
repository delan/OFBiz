package dataclass;    

import pattern.*;

public interface IFieldSupportClass extends IDataSupportClass {
}
