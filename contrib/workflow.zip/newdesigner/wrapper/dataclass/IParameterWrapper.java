package dataclass; 

public interface IParameterWrapper extends IParameter, IParameterSupportClass, pattern.IRegistrar {
}
