package dataclass; 

public interface IFieldListWrapper extends IFieldList, IFieldListSupportClass, pattern.IRegistrar {
}
